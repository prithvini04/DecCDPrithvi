**To get the usage details for a Usage Plan**

Command::

  aws apigateway get-usage --usage-plan-id a1b2c3 --start-date "2016-08-16" --end-date "2016-08-17"
